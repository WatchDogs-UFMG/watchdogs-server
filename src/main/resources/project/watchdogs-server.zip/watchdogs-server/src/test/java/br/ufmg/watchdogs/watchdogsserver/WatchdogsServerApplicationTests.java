package br.ufmg.watchdogs.watchdogsserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WatchdogsServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
